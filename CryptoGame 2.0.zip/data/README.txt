This folder contains all persistent data files for the CryptoGame project.

Files:
- Portfolio.csv: Your current stock holdings and buy info.
- portfolio_history.csv: Daily snapshots of your portfolio value.
- cashBalance.txt: Your current available cash balance.
- points.txt: Your current achievement points.
- achievements.json: Tracks which achievements you have unlocked.

Do not delete or manually edit these files unless you know what you are doing.
